#!/bin/bash

npm run build && gulp